import { useForm, SubmitHandler } from 'react-hook-form';
import { Box, CircularProgress, Typography } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import { MuiTelInput } from 'mui-tel-input';
import { FormField } from 'src/components/form-fields/form-field';
import { AddressFieldGroup } from 'src/components/form-fields/address-form-group';
import { FormSelectField } from 'src/components/form-fields/form-select-field';
import { AutocompleteMultiSelectField } from 'src/components/form-fields/autocomplete-multi-select-field';
import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { FormPhoneNumberField } from 'src/components/form-fields/tel-form-field';

interface UserFormData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmPassword: string;
  address: {
    street: string;
    city: string;
    state: string;
    country: string;
    postalCode?: string;
    comment?: string;
  };
  phoneNumber: string;
  branchId: number;
  roles: string[];
}

interface SelectOption {
  value: string | number;
  label: string;
}

export function AddNewUserForm() {
  const { control, handleSubmit, watch, formState: { errors } } = useForm<UserFormData>({
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      confirmPassword: '',
      address: {
        street: '',
        city: '',
        state: '',
        country: '',
        postalCode: '',
        comment: '',
      },
      phoneNumber: '',
      branchId: 2,
      roles: [],
    },
  });

  const password = watch('password');
  const [loading, setLoading] = useState(false);
  const [submissionError, setSubmissionError] = useState<string | null>(null);

  const onSubmit: SubmitHandler<UserFormData> = async (data) => {
    setLoading(true);
    setSubmissionError(null); // Reset error state before submission
  
    try {
      const response = await fetch('http://localhost:5184/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
  
      if (!response.ok) {
        const errorResponse = await response.json(); // Parse the error response
        const errorMessages = errorResponse.errorMessages || ["An unknown error occurred."];
        // Set the error messages to state
        setSubmissionError(errorMessages.join(', ')); // Join error messages into a single string
        return; // Early return to avoid executing the success block
      }
  
      console.log('User added successfully');
      // Optionally reset the form or show a success message
    } catch (error: any) {
      console.log(error);
      setSubmissionError("An unexpected error occurred. Please try again."); // Handle unexpected errors
    } finally {
      setLoading(false);
    }
  };

  function useBranches() {
    return useQuery({
      queryKey: ['branches'],
      queryFn: async (): Promise<Array<SelectOption>> => {
        const response = await fetch('http://localhost:5184/branches');
        const result = await response.json();
        return result.value;
      },
      staleTime: 1000 * 60 * 5,
      refetchOnWindowFocus: false,
    });
  }

  function useRoles() {
    return useQuery({
      queryKey: ['roles'],
      queryFn: async (): Promise<Array<{ value: string; label: string }>> => {
        const response = await fetch('http://localhost:5184/auth/roles');
        const result = await response.json();
        const rolesList = result.value.map((role: string) => ({ value: role, label: role }));
        return rolesList;
      },
      staleTime: 1000 * 60 * 5,
      refetchOnWindowFocus: false,
    });
  }

  const { data: branches, error: branchesError, isLoading: isLoadingBranches } = useBranches();
  const { data: roles, error: rolesError, isLoading: isLoadingRoles } = useRoles();

  if (isLoadingBranches || isLoadingRoles) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <CircularProgress />
        <Typography variant="h6" sx={{ marginLeft: 2 }}>
          Loading...
        </Typography>
      </Box>
    );
  }

  // Error handling for branches and roles loading
  if (branchesError || rolesError) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <Typography color="error">{branchesError?.message} {rolesError?.message}</Typography>
      </Box>
    );
  }

  return (
    <Box component="form" autoComplete="off" sx={{ mt: 3 }} onSubmit={handleSubmit(onSubmit)}>
      <Typography variant="h6" gutterBottom>
        Add New User
      </Typography>
      
      {/* Form Fields */}
      <FormField<UserFormData>
        name="firstName"
        control={control}
        label="First Name"
        rules={{ required: 'First name is required' }}
        error={!!errors.firstName}
        helperText={errors.firstName?.message}
      />

      <FormField<UserFormData>
        name="lastName"
        control={control}
        label="Last Name"
        rules={{ required: 'Last name is required' }}
        error={!!errors.lastName}
        helperText={errors.lastName?.message}
      />

      <FormField<UserFormData>
        name="email"
        type='email'
        control={control}
        label="Email"
        rules={{ required: 'email is required' }}
        error={!!errors.lastName}
        helperText={errors.lastName?.message}
      />

      <FormField<UserFormData>
        name="password"
        control={control}
        label="Password"
        type="password"
        showPasswordToggle
        rules={{
          required: 'Password is required',
          minLength: {
            value: 8,
            message: 'Password must be at least 8 characters long',
          },
        }}
        error={!!errors.password}
        helperText={errors.password?.message}
      />

      <FormField<UserFormData>
        name="confirmPassword"
        control={control}
        label="Confirm Password"
        type="password"
        showPasswordToggle
        rules={{
          required: 'Please confirm your password',
          validate: (value) => value === password || 'The passwords do not match',
        }}
        error={!!errors.confirmPassword}
        helperText={errors.confirmPassword?.message}
      />

      <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
        Address
      </Typography>
      <AddressFieldGroup<UserFormData> control={control} prefix="address" errors={errors.address} />

      {/* <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
        Phone Number
      </Typography>
      <FormField<UserFormData>
        name="phoneNumber"
        control={control}
        label="Phone Number"
        rules={{ required: 'Phone number is required' }}
        render={({ field }) => (
          <MuiTelInput
            {...field}
            onlyCountries={['EG']}
            defaultCountry="EG"
            fullWidth
            margin="normal"
          />
        )}
        error={!!errors.phoneNumber}
        helperText={errors.phoneNumber?.message}
      /> */}

      <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
        Phone Number
      </Typography>
      <FormPhoneNumberField<UserFormData>
        name="phoneNumber"
        control={control}
        label="Phone Number"
        rules={{ required: 'Phone number is required' }} // Additional required rule
        error={!!errors.phoneNumber}
        helperText={errors.phoneNumber?.message}
      />

      <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
        Branch
      </Typography>
      <FormSelectField<UserFormData>
        name="branchId"
        control={control}
        rules={{ required: 'User Branch is required' }}
        error={!!errors.branchId}
        helperText={errors.branchId?.message}
        options={branches || []}
      />

      <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
        User roles
      </Typography>
      <AutocompleteMultiSelectField<UserFormData>
        name="roles"
        control={control}
        rules={{ required: 'User Role is required' }}
        error={!!errors.roles}
        helperText={errors.roles?.message}
        options={roles || []}
      />

      <LoadingButton
        fullWidth
        size="large"
        type="submit"
        variant="contained"
        sx={{ mt: 3 }}
        loading={loading} // Show loading state
      >
        Add User
      </LoadingButton>

      {/* Display submission error if exists */}
      {submissionError && (
        <Typography color="error" sx={{ mt: 2 }}>
          {submissionError}
        </Typography>
      )}

      {/* Overlay while loading */}
      {loading && (
        <Box
          sx={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000,
          }}
        >
          <CircularProgress />
        </Box>
      )}
    </Box>
  );
}
