import { useState, useEffect, useCallback } from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Table from '@mui/material/Table';
import Button from '@mui/material/Button';
import TableBody from '@mui/material/TableBody';
import Typography from '@mui/material/Typography';
import TableContainer from '@mui/material/TableContainer';
import TablePagination from '@mui/material/TablePagination';

import { DashboardContent } from 'src/layouts/dashboard';
import { Iconify } from 'src/components/iconify';
import { Scrollbar } from 'src/components/scrollbar';
import { TableNoData } from '../table-no-data';
import { UserTableRow } from '../user-table-row';
import { UserTableHead } from '../user-table-head';
import { TableEmptyRows } from '../table-empty-rows';
import { UserTableToolbar } from '../user-table-toolbar';
import { emptyRows, applyFilter, getComparator } from '../utils';
import { AddNewUserForm } from '../add-new-user';
import { CustomDialog } from 'src/layouts/components/custom-dialog';
import type { UserProps } from '../user-table-row';
import { PaginationParameters } from 'src/services/pagination-parameters';

// ----------------------------------------------------------------------

interface ApiResponse {
  value: {
    totalCount: number;
    pageNumber: number;
    pageSize: number;
    data: Array<{
      userId: string;
      userName: string;
      email: string;
      phoneNumber: string | null;
      isAccountDisabled: boolean;
      branchId: number;
      roles: string[];
    }>;
  };
  isSuccess: boolean;
  statusCode: number;
  message: string;
}

export function UserView() {
  const table = useTable();
  const [filterName, setFilterName] = useState('');
  const [openDialog, setOpenDialog] = useState(false);
  const [users, setUsers] = useState<UserProps[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState(0);

  const fetchUsers = async (params: PaginationParameters) => {
    setLoading(true);
    try {
      const filteredParams = Object.entries(params).reduce((acc, [key, value]) => {
        if (value !== null && value !== undefined && value !== '') {
          acc[key as keyof PaginationParameters] = value;
        }
        return acc;
      }, {} as Partial<PaginationParameters>);

      const queryString = new URLSearchParams(filteredParams as Record<string, string>).toString();
      const response = await fetch(`http://localhost:5184/auth/users${queryString ? `?${queryString}` : ''}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }
      const apiResponse: ApiResponse = await response.json();
      
      if (apiResponse.isSuccess && apiResponse.value.data) {
        const transformedUsers: UserProps[] = apiResponse.value.data.map(user => ({
          id: user.userId,
          name: user.userName,
          email: user.email,
          role: user.roles.join(', ') || 'No Role',
          status: user.isAccountDisabled ? 'Disabled' : 'Active',
          branchId: user.branchId,
          phoneNumber: user.phoneNumber
        }));
        setUsers(transformedUsers);
        setTotalCount(apiResponse.value.totalCount);
      } else {
        throw new Error(apiResponse.message || 'Failed to fetch users');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const params: PaginationParameters = {
      PageNumber: table.page + 1,
      PageSize: table.rowsPerPage,
      SortBy: table.orderBy,
      SortDescending: table.order === 'desc',
      SearchTerm: filterName || undefined,
    };
    fetchUsers(params);
  }, [table.page, table.rowsPerPage, table.order, table.orderBy, filterName]);

  const dataFiltered = applyFilter({
    inputData: users,
    comparator: getComparator(table.order, table.orderBy),
    filterName,
  });

  const handleOpenDialog = () => setOpenDialog(true);
  const handleCloseDialog = () => setOpenDialog(false);

  const notFound = !dataFiltered.length && !!filterName;

  return (
    <DashboardContent>
      <Box display="flex" alignItems="center" mb={5}>
        <Typography variant="h4" flexGrow={1}>Users</Typography>
        <Button
          variant="contained"
          color="inherit"
          startIcon={<Iconify icon="mingcute:add-line" />}
          onClick={handleOpenDialog}
        >
          New user
        </Button>
      </Box>

      <Card>
        <UserTableToolbar
          numSelected={table.selected.length}
          filterName={filterName}
          onFilterName={(event: React.ChangeEvent<HTMLInputElement>) => {
            setFilterName(event.target.value);
            table.onResetPage();
          }}
        />

        <Scrollbar>
          <TableContainer sx={{ overflow: 'unset' }}>
            <Table sx={{ minWidth: 800 }}>
              <UserTableHead
                order={table.order}
                orderBy={table.orderBy}
                rowCount={users.length}
                numSelected={table.selected.length}
                onSort={table.onSort}
                onSelectAllRows={(checked) =>
                  table.onSelectAllRows(
                    checked,
                    users.map((user) => user.id)
                  )
                }
                headLabel={[
                  { id: 'UserName', label: 'Name' },
                  { id: 'Email', label: 'Email' },
                  { id: 'role', label: 'Role' },
                  { id: 'BranchId', label: 'Branch ID' },
                  { id: 'IsAccountDisabled', label: 'Status' },
                  { id: 'PhoneNumber', label: 'Phone Number' },
                  { id: '' },
                ]}
              />
              <TableBody>
                {loading && <TableNoData searchQuery="Loading..." />}
                {error && <TableNoData searchQuery={error} />}
                {dataFiltered.map((row) => (
                  <UserTableRow
                    key={row.id}
                    row={row}
                    selected={table.selected.includes(row.id)}
                    onSelectRow={() => table.onSelectRow(row.id)}
                  />
                ))}

                <TableEmptyRows
                  height={68}
                  emptyRows={emptyRows(table.page, table.rowsPerPage, users.length)}
                />

                {notFound && <TableNoData searchQuery={filterName} />}
              </TableBody>
            </Table>
          </TableContainer>
        </Scrollbar>

        <TablePagination
          component="div"
          page={table.page}
          count={totalCount}
          rowsPerPage={table.rowsPerPage}
          onPageChange={table.onChangePage}
          rowsPerPageOptions={[5, 10, 25]}
          onRowsPerPageChange={table.onChangeRowsPerPage}
        />
      </Card>
      <CustomDialog open={openDialog} handleClose={handleCloseDialog} title={'Add new User'} content={<AddNewUserForm />} />
    </DashboardContent>
  );
}

// ----------------------------------------------------------------------

export function useTable() {
  const [page, setPage] = useState(0);
  const [orderBy, setOrderBy] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [selected, setSelected] = useState<string[]>([]);
  const [order, setOrder] = useState<'asc' | 'desc'>('asc');

  const onSort = useCallback(
    (id: string) => {
      const isAsc = orderBy === id && order === 'asc';
      setOrder(isAsc ? 'desc' : 'asc');
      setOrderBy(id);
    },
    [order, orderBy]
  );

  const onSelectAllRows = useCallback((checked: boolean, newSelecteds: string[]) => {
    if (checked) {
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  }, []);

  const onSelectRow = useCallback(
    (inputValue: string) => {
      const newSelected = selected.includes(inputValue)
        ? selected.filter((value) => value !== inputValue)
        : [...selected, inputValue];

      setSelected(newSelected);
    },
    [selected]
  );

  const onResetPage = useCallback(() => {
    setPage(0);
  }, []);

  const onChangePage = useCallback((event: unknown, newPage: number) => {
    setPage(newPage);
  }, []);

  const onChangeRowsPerPage = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      setRowsPerPage(parseInt(event.target.value, 10));
      onResetPage();
    },
    [onResetPage]
  );

  return {
    page,
    order,
    onSort,
    orderBy,
    selected,
    rowsPerPage,
    onSelectRow,
    onResetPage,
    onChangePage,
    onSelectAllRows,
    onChangeRowsPerPage,
  };
}