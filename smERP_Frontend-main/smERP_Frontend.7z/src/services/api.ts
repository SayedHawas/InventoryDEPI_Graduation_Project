import { useMutation, useQuery, UseQueryOptions } from '@tanstack/react-query';
import { jwtDecode } from 'jwt-decode';

// Define the base URL for your API
const API_BASE_URL = 'https://taambeit.runasp.net';

// Types for our auth responses
interface LoginResponse {
  jwt: string;
  user: User;
}

interface RefreshResponse {
  jwt: string;
}

interface User {
  id: string;
  email: string;
  role: string[];
  unique_name: string
}

interface JwtPayload {
  id: string;
  email: string;
  userName: string;
  firstName: string;
  lastName: string;
  role: string[];
  exp: number;
}

// Helper function to handle API calls
const apiCall = async <T>(
  endpoint: string,
  method: string,
  body?: object,
  token?: string
): Promise<T> => {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'include', // This is important for sending and receiving cookies
  });

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  return response.json();
};

// Function to handle login
const loginUser = async (credentials: { email: string; password: string }) => {
  const data = await apiCall<LoginResponse>('/Auth/login', 'POST', credentials);
  localStorage.setItem('accessToken', data.jwt);
  const user: User = jwtDecode<User>(data.jwt)
  localStorage.setItem('user', JSON.stringify(user));
  return data;
};

// Function to handle logout
const logoutUser = async () => {
  localStorage.removeItem('accessToken');
  localStorage.removeItem('user');
  await apiCall('/Auth/revokeToken', 'GET');
};

// Function to refresh the access token
const refreshAccessToken = async () => {
  const data = await apiCall<RefreshResponse>('/Auth/refreshToken', 'GET');
  localStorage.setItem('accessToken', data.jwt);
  const user: User = jwtDecode<User>(data.jwt)
  localStorage.setItem('user', JSON.stringify(user));
  return data;
};

export const useLogin = () => {
  const mutation = useMutation({
    mutationFn: loginUser,
  });

  return {
    login: mutation.mutate,
    isLoading: mutation.status === 'pending',
    ...mutation,
  };
};

export const useLogout = () => 
  useMutation({mutationFn: logoutUser});


// Custom hook for token refresh mutation
export const useRefreshToken = () => 
   useMutation({mutationFn: refreshAccessToken});


export const isTokenExpired = (token?: string): boolean => {
  // Use the provided token or retrieve from local storage
  const tokenToCheck = token || localStorage.getItem('accessToken');

  if (!tokenToCheck) {
    // No token available to check
    return true;
  }

  try {
    // Decode the token
    const decodedToken = jwtDecode<JwtPayload>(tokenToCheck);
    // Check if the token is expired
    return decodedToken.exp * 1000 < Date.now();
  } catch {
    // If decoding fails, assume the token is expired
    return true;
  }
};

// Custom hook to get authenticated fetch function
export const useAuthenticatedFetch = () => {
  const refreshTokenMutation = useRefreshToken();

  return async (input: RequestInfo, init?: RequestInit) => {
    let accessToken = localStorage.getItem('accessToken') || '';

    if (!accessToken || isTokenExpired(accessToken)) {
      try {
        const refreshResult = await refreshTokenMutation.mutateAsync();
        accessToken = refreshResult.jwt;
      } catch (error) {
        throw new Error('Unable to refresh token');
      }
    }

    const headers = new Headers(init?.headers);
    headers.set('Authorization', `Bearer ${accessToken}`);

    const response = await fetch(input, { ...init, headers });

    if (response.status === 401) {
      throw new Error('Unauthorized');
    }

    return response;
  };
};

// Custom hook for authenticated queries
export const useAuthenticatedQuery = <TData>(
  key: string[],
  queryFn: () => Promise<TData>,
  options?: Omit<UseQueryOptions<TData, Error>, 'queryKey' | 'queryFn'>
) => {
  const authenticatedFetch = useAuthenticatedFetch();

  return useQuery<TData, Error>({
    queryKey: key,
    queryFn: async () => {
      try {
        const response = await authenticatedFetch(queryFn.toString());
        return await response.json();
      } catch (error) {
        if (error instanceof Error && error.message === 'Unauthorized') {
          localStorage.removeItem('accessToken');
          localStorage.removeItem('user');
        }
        throw error;
      }
    },
    retry: (failureCount: number, error: Error) => {
      if (error instanceof Error && error.message === 'Unauthorized') {
        return false;
      }
      return failureCount < 3;
    },
    ...options,
  });
};

export { apiCall };